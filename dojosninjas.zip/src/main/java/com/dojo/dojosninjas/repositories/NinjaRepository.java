package com.dojo.dojosninjas.repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.dojo.dojosninjas.models.Dojo;
import com.dojo.dojosninjas.models.Ninja;

@Repository
//interface CrudRepository<T,Id> (T equals entity)
public interface NinjaRepository extends CrudRepository<Ninja, Long>{ //CrudRepository built-in to Spring
	// this method retrieves all the Ninja's from the database
	List<Ninja> findAll(); 
	// this method retrieves all the Ninja's from the database from a particular dojo
	List<Ninja> findAllByDojo(Dojo dojo);

}
