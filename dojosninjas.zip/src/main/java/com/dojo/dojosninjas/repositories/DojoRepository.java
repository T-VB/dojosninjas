package com.dojo.dojosninjas.repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.dojo.dojosninjas.models.Dojo;

@Repository
//interface CrudRepository<T,Id> (T equals entity)
public interface DojoRepository extends CrudRepository<Dojo, Long>{ //CrudRepository built-in to Spring
	// this method retrieves all the Dojo's from the database
	List<Dojo> findAll();
	
}