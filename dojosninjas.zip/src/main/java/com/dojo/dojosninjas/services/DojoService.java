package com.dojo.dojosninjas.services;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.dojo.dojosninjas.models.Dojo;
import com.dojo.dojosninjas.repositories.DojoRepository;

@Service
public class DojoService {

	//creating the instance (expenseRepository) that will be used to call all the methods from the repository.
    private final DojoRepository dojoRepository;
    
    //adding the dojo repository as a dependency
    public DojoService(DojoRepository dojoRepository) {
        this.dojoRepository = dojoRepository;
    }
    // returns all the dojos
    public List<Dojo> allDojos() {
        return this.dojoRepository.findAll();
    }
    // creates a dojo and saves it
    public Dojo createDojo(Dojo dojo) {
        return this.dojoRepository.save(dojo);
    }
    // retrieves a single dojo by id
    public Dojo findDojo(Long id) {
        return dojoRepository.findById(id).orElse(null);
    }
	
}
