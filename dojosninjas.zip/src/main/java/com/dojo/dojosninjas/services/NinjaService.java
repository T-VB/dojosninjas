package com.dojo.dojosninjas.services;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.dojo.dojosninjas.models.Ninja;
import com.dojo.dojosninjas.repositories.NinjaRepository;

@Service
public class NinjaService {

	//creating the instance (ninjaRepository) that will be used to call all the methods from the repository.
    private final NinjaRepository ninjaRepository;
    
    //adding the ninja repository as a dependency
    public NinjaService(NinjaRepository ninjaRepository) {
        this.ninjaRepository = ninjaRepository;
    }
    // returns all the ninjas
    public List<Ninja> allNinjas() {
        return this.ninjaRepository.findAll();
    }
    // creates a ninja and saves it
    public Ninja createNinja(Ninja ninja) {
        return this.ninjaRepository.save(ninja);
    }
    // retrieves a ninja by id
    public Ninja findNinja(Long id) {
        Optional<Ninja> optionalNinja = ninjaRepository.findById(id);
        if(optionalNinja.isPresent()) {
            return optionalNinja.get();
        } else {
            return null;
        }
    }
	
}
	



