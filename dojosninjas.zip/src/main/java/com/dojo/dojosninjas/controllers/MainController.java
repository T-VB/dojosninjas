package com.dojo.dojosninjas.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.dojo.dojosninjas.models.Dojo;
import com.dojo.dojosninjas.models.Ninja;
import com.dojo.dojosninjas.services.DojoService;
import com.dojo.dojosninjas.services.NinjaService;

@Controller
public class MainController {

	//Services:
	@Autowired //instantiate Services for each:
	private NinjaService ninjas;
	@Autowired
	private DojoService dojos;
	
	//GET Routes
	@GetMapping("/dojos/new")
	public String newDojo(@ModelAttribute("dojo") Dojo dojo) {
		return "new_dojo.jsp";
	}
	
	@GetMapping("/ninjas/new")
	public String newNinja(@ModelAttribute("ninja") Ninja ninja, Model model) {
		model.addAttribute("dojos", dojos.allDojos());
		return "new_ninja.jsp";
	}
	
	@GetMapping("/dojos/{id}")
	public String showDojo(@PathVariable("id") Long id, Model model) {
		Dojo dojo = dojos.findDojo(id);
		model.addAttribute("dojo", dojo);
		return "show_dojo.jsp";
	}
	
	//POST Routes / Redirect Routes
	
	@PostMapping("/dojos")
	public String createDojo(@ModelAttribute("dojo") Dojo dojo) {
		Dojo newDojo = dojos.createDojo(dojo);
		return String.format("redirect:/dojos/%s", newDojo.getId());
	}
	
	//****POST mapping for the many in one to many:
	@PostMapping("/ninjas")
	public String createNinja(@ModelAttribute("ninja") Ninja ninja) {
		ninja = ninjas.createNinja(ninja);
		return "redirect:/dojos/" + ninja.getDojo().getId();
	}
}
