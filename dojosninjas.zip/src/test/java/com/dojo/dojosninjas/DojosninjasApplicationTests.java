package com.dojo.dojosninjas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DojosninjasApplicationTests {

	@Test
	void contextLoads() {
	}

}
